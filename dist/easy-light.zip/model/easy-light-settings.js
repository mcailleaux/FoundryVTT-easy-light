export default class EasyLightSettings {
}
//# sourceMappingURL=easy-light-settings.js.map