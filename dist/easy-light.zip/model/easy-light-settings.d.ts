export default class EasyLightSettings {
}
