export default class EasyLightSettings {}
