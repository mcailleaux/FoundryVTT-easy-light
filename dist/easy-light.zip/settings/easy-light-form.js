var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import EasyLightSettings from '../model/easy-light-settings.js';
import RegisterSettings from './register-settings.js';
export default class EasyLightForm extends FormApplication {
    constructor(object, options = {}) {
        super(object, options);
    }
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            id: 'easy-light-settings',
            title: game.i18n.localize('EASYLIGHT.settings.form.name'),
            template: `modules/${RegisterSettings.moduleName}/templates/easy-light-settings.html`,
            width: 800,
            height: 'auto',
            resizable: true,
            closeOnSubmit: true,
        });
    }
    getData() {
        if (this.data == null) {
            const easyLightSettings = Object.assign(Object.assign({}, new EasyLightSettings()), duplicate(game.settings.get(RegisterSettings.moduleName, 'easyLightSettings')));
            this.data = easyLightSettings;
        }
        return {
            easyLight: this.data,
        };
    }
    activateListeners(html) {
        super.activateListeners(html);
    }
    _getSubmitData(_updateData) {
        return this.data;
    }
    _updateObject(_event, formData) {
        return __awaiter(this, void 0, void 0, function* () {
            const easyLightSettings = duplicate(formData);
            yield game.settings.set(RegisterSettings.moduleName, 'easyLightSettings', easyLightSettings);
        });
    }
    close(options) {
        this.data = null;
        return super.close(options);
    }
}
//# sourceMappingURL=easy-light-form.js.map