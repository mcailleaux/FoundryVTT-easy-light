import EasyLightForm from './easy-light-form.js';
import EasyLightSettings from '../model/easy-light-settings.js';
export default class RegisterSettings {
    static initSettings() {
        var _a, _b;
        const mainModule = 'easy-light';
        const betaModule = 'easy-light-beta';
        const mainModuleActive = (_a = game.modules.get(mainModule)) === null || _a === void 0 ? void 0 : _a.active;
        const betaModuleActive = (_b = game.modules.get(betaModule)) === null || _b === void 0 ? void 0 : _b.active;
        if (mainModuleActive) {
            this.moduleName = mainModule;
            this.registerSettings(mainModule);
        }
        if (betaModuleActive) {
            this.moduleName = betaModule;
            this.registerSettings(betaModule);
        }
    }
    static registerSettings(moduleName) {
        game.settings.registerMenu(moduleName, 'easyLightForm', {
            name: game.i18n.localize('EASYLIGHT.settings.form.name'),
            label: game.i18n.localize('EASYLIGHT.settings.form.label'),
            hint: game.i18n.localize('EASYLIGHT.settings.form.hint'),
            icon: 'fas fa-id-card',
            type: EasyLightForm,
            restricted: true,
        });
        game.settings.register(moduleName, 'easyLightSettings', {
            name: game.i18n.localize('EASYLIGHT.settings.name'),
            hint: game.i18n.localize('EASYLIGHT.settings.hint'),
            default: new EasyLightSettings(),
            scope: 'world',
            type: Object,
            onChange: (_s) => { },
        });
    }
}
//# sourceMappingURL=register-settings.js.map