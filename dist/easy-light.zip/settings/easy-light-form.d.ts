/// <reference types="jquery" />
import EasyLightSettings from '../model/easy-light-settings.js';
export default class EasyLightForm extends FormApplication<EasyLightSettings> {
    private data;
    constructor(object: EasyLightSettings, options?: FormApplication.Options);
    static get defaultOptions(): FormApplication.Options;
    getData(): any;
    activateListeners(html: JQuery): void;
    protected _getSubmitData(_updateData?: object): any;
    _updateObject(_event: Event, formData: any): Promise<void>;
    close(options?: object): Promise<void>;
}
