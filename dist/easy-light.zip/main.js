import RegisterSettings from './settings/register-settings.js';
Hooks.once('init', () => {
    RegisterSettings.initSettings();
});
//# sourceMappingURL=main.js.map